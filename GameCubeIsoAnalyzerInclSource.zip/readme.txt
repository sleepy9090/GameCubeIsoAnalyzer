GameCube ISO Analyzer Version 1.0.0.30103 + Source
Coded by: Shawn M. Crawford [sleepy9090]
January 12, 2015

Requires .NET Framework
Source can be opened/built with Visual Studio 2013

Open a GameCube ISO/GCM and the following information is read from it:
Filename
Game Name
Console ID
Game Code
Country Code
Maker Code
Disc ID
Version
DVD Magic Word
Debug Monitor Offset (dh.bin)
Address to Load the Debug Monitor
Offset of the Main Executable DOL (bootfile)
Offset of the FST (fst.bin)
FST Size
Max FST Size
